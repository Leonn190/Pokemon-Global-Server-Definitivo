import pygame

from Codigo.ModulosGerais.Sonoridades import VerificaSonoridade
from Codigo.Prefabs.Barra import BarraEditavel
from Codigo.Prefabs.Botao import Botao, BotaoAlavanca
from Codigo.Prefabs.Texto import Texto
from Codigo.Telas.Telas.TelaConfigAvancada import TelaConfigAvancada
from Codigo.Telas.Telas.TelaConta import TelaConta
from Codigo.Telas.Telas.TelasGenericas import SubtelaConfirmacao

_CONFIG_CARREGADA = False
_TAMANHO_CACHE = (0, 0)

_BARRAS = {}
_BOTOES_TOGGLE = {}
_BOTAO_SALVAR = None
_BOTAO_CANCELAR = None
_BOTAO_CONFIG_AVANCADA = None
_BOTAO_CONTA = None
_TITULO = None

_SUBTELA_ATIVA = None

_CONFIG_INICIAL = None


def _estilo_base():
    return {
        "radius": 18,
        "border_width": 2,
        "border": (18, 24, 44),
        "border_hover": (255, 220, 120),
        "bg": (40, 56, 98),
        "bg_hover": (58, 79, 136),
        "bg_pressed": (34, 47, 82),
        "hover_scale": 1.03,
        "hover_speed": 10.0,
        "press_scale": 0.97,
        "text_style": {
            "size": 28,
            "color": (245, 246, 255),
            "hover_color": (255, 235, 130),
            "hover_speed": 18.0,
            "align": "center",
            "outline": True,
            "outline_color": (0, 0, 0),
            "outline_thickness": 1,
            "shadow": True,
            "shadow_color": (0, 0, 0, 160),
            "shadow_offset": (2, 2),
        },
    }


def salvar_config_fixa(config):
    from pathlib import Path

    dados = dict(config)
    conta_info = dados.get("ContaInfo")
    if isinstance(conta_info, dict):
        conta_info = dict(conta_info)
        conta_info.pop("servidores_registrados", None)
        dados["ContaInfo"] = conta_info

    caminho = Path("Outros/ConfigFixa.py")
    caminho.write_text("ConfigFixa = " + repr(dados) + "\n", encoding="utf-8")


def _voltar_menu(Cena, JOGO):
    retorno = JOGO.INFO.pop("ConfigRetorno", None)
    if isinstance(retorno, dict) and retorno.get("Cena") == "Mundo":
        JOGO.CenaAlvo = "Mundo"
        return
    cena_atual = getattr(JOGO, "Cena", None)
    cena_id = str(getattr(cena_atual, "ID", "") or "")
    if cena_id == "Mundo":
        if callable(getattr(cena_atual, "DefinirTela", None)):
            cena_atual.DefinirTela(None)
        else:
            cena_atual.TelaAtual = None
        return
    if cena_id == "Combate":
        if callable(getattr(cena_atual, "DefinirTela", None)):
            cena_atual.DefinirTela("Combate")
        else:
            cena_atual.TelaAtual = "Combate"
        return
    Cena.DefinirTela("MenuPrincipal")


def _ao_toggle(chave, jogo, estado):
    jogo.CONFIG[chave] = estado
    if chave == "Mudo":
        VerificaSonoridade(jogo.CONFIG)


def _executar_cancelar(Cena, JOGO, botao):
    JOGO.CONFIG.clear()
    JOGO.CONFIG.update(_CONFIG_INICIAL)

    _BARRAS["FPS"].set_valor(JOGO.CONFIG["FPS"])
    _BARRAS["Claridade"].set_valor(JOGO.CONFIG["Claridade"])
    _BARRAS["Volume"].set_valor(JOGO.CONFIG["Volume"] * 100)

    for chave, botao_toggle in _BOTOES_TOGGLE.items():
        botao_toggle.set_estado(bool(JOGO.CONFIG.get(chave, False)))

    VerificaSonoridade(JOGO.CONFIG)
    _voltar_menu(Cena, JOGO)


def _executar_salvar(Cena, JOGO, botao):
    salvar_config_fixa(JOGO.CONFIG)
    _voltar_menu(Cena, JOGO)


def _confirmar_deslogar(Cena, JOGO):
    JOGO.CONFIG["Usuario"] = None
    JOGO.CONFIG["ContaInfo"] = {}
    salvar_config_fixa(JOGO.CONFIG)
    Cena.DefinirTela("MenuPrincipal")
    JOGO.CenaAlvo = "Login"


def _abrir_confirmacao_deslogar(Cena, JOGO):
    JOGO.GerenciadorSubtelas.abrir(SubtelaConfirmacao(
        JOGO.TELA.get_size(),
        "Você será desconectado da conta atual.",
        confirmar_callback=lambda: _confirmar_deslogar(Cena, JOGO),
        titulo="Confirmar logout",
    ))


def _abrir_subtela_avancada(Cena, JOGO, botao):
    global _SUBTELA_ATIVA
    _SUBTELA_ATIVA = TelaConfigAvancada(
        JOGO,
        _estilo_base(),
        confirmar_callback=lambda: _confirmar_config_avancada(JOGO),
        cancelar_callback=_fechar_subtela,
    )


def _abrir_subtela_conta(Cena, JOGO, botao):
    global _SUBTELA_ATIVA
    _SUBTELA_ATIVA = TelaConta(
        JOGO,
        _estilo_base(),
        deslogar_callback=lambda: _abrir_confirmacao_deslogar(Cena, JOGO),
        voltar_callback=_fechar_subtela,
    )


def _fechar_subtela():
    global _SUBTELA_ATIVA
    _SUBTELA_ATIVA = None


def _confirmar_config_avancada(jogo):
    global _CONFIG_INICIAL
    salvar_config_fixa(jogo.CONFIG)
    _CONFIG_INICIAL = dict(jogo.CONFIG)
    _fechar_subtela()


def _montar_layout(Cena, JOGO):
    global _CONFIG_CARREGADA, _TAMANHO_CACHE, _CONFIG_INICIAL
    global _BARRAS, _BOTOES_TOGGLE, _BOTAO_SALVAR, _BOTAO_CANCELAR, _BOTAO_CONFIG_AVANCADA, _BOTAO_CONTA, _TITULO

    largura_tela, altura_tela = JOGO.TELA.get_size()
    estilo = _estilo_base()

    _CONFIG_INICIAL = dict(JOGO.CONFIG)

    largura_barra = min(900, int(largura_tela * 0.68))
    x_barra = (largura_tela - largura_barra) // 2
    y_inicial = int(altura_tela * 0.20)
    espacamento = 110

    _BARRAS = {
        "FPS": BarraEditavel(pygame.Rect(x_barra, y_inicial + espacamento * 0, largura_barra, 26), "FPS", JOGO.CONFIG["FPS"], 30, 300, 0),
        "Claridade": BarraEditavel(pygame.Rect(x_barra, y_inicial + espacamento * 1, largura_barra, 26), "Claridade", JOGO.CONFIG["Claridade"], 0, 100, 0),
        "Volume": BarraEditavel(pygame.Rect(x_barra, y_inicial + espacamento * 2, largura_barra, 26), "Volume", JOGO.CONFIG["Volume"] * 100, 0, 100, 0),
    }

    largura_toggle = 320
    altura_toggle = 70
    espaco_x = 30
    y_toggles = y_inicial + espacamento * 3 + 20
    x_toggles = (largura_tela - (largura_toggle * 2 + espaco_x)) // 2

    _BOTOES_TOGGLE = {}
    for i, chave in enumerate(("Mudo", "Shader")):
        x = x_toggles + i * (largura_toggle + espaco_x)
        y = y_toggles
        estilo_toggle = dict(estilo)
        estilo_toggle["text_style"] = dict(estilo["text_style"])
        _BOTOES_TOGGLE[chave] = BotaoAlavanca(
            pygame.Rect(x, y, largura_toggle, altura_toggle),
            chave,
            estado_inicial=bool(JOGO.CONFIG.get(chave, False)),
            execute=lambda jogo, estado, botao, chave=chave: _ao_toggle(chave, jogo, estado),
            style=estilo_toggle,
        )

    largura_sub = 320
    altura_sub = 76
    y_sub = y_toggles + altura_toggle + 22

    _BOTAO_CONFIG_AVANCADA = Botao(
        pygame.Rect(x_toggles, y_sub, largura_sub, altura_sub),
        "Config avançada",
        execute=lambda jogo, botao: _abrir_subtela_avancada(Cena, jogo, botao),
        style=estilo,
    )
    _BOTAO_CONTA = Botao(
        pygame.Rect(x_toggles + largura_toggle + espaco_x, y_sub, largura_sub, altura_sub),
        "Conta",
        execute=lambda jogo, botao: _abrir_subtela_conta(Cena, jogo, botao),
        style=estilo,
    )

    estilo_acao = dict(estilo)
    estilo_acao["text_style"] = dict(estilo["text_style"])
    estilo_acao["text_style"]["size"] = 34

    largura_acao = 260
    altura_acao = 80
    y_acao = int(altura_tela * 0.88)
    x_cancelar = largura_tela // 2 - largura_acao - 20
    x_salvar = largura_tela // 2 + 20

    _BOTAO_CANCELAR = Botao(
        pygame.Rect(x_cancelar, y_acao, largura_acao, altura_acao),
        "Cancelar",
        execute=lambda jogo, botao: _executar_cancelar(Cena, jogo, botao),
        style=estilo_acao,
    )
    _BOTAO_SALVAR = Botao(
        pygame.Rect(x_salvar, y_acao, largura_acao, altura_acao),
        "Salvar",
        execute=lambda jogo, botao: _executar_salvar(Cena, jogo, botao),
        style=estilo_acao,
    )

    _TITULO = Texto(
        "Configurações",
        pos=(largura_tela // 2, int(altura_tela * 0.08)),
        style={
            "size": 54,
            "align": "center",
            "outline": True,
            "outline_color": (0, 0, 0),
            "outline_thickness": 2,
            "shadow": True,
            "shadow_color": (0, 0, 0, 180),
            "shadow_offset": (2, 2),
        },
    )

    _TAMANHO_CACHE = (largura_tela, altura_tela)
    _CONFIG_CARREGADA = True


def ResetTelaConfig():
    global _CONFIG_CARREGADA, _SUBTELA_ATIVA
    _CONFIG_CARREGADA = False
    _SUBTELA_ATIVA = None


def TelaConfig(Cena, JOGO, EVENTOS, dt, tela_destino=None):
    largura_tela, altura_tela = JOGO.TELA.get_size()
    if (not _CONFIG_CARREGADA) or _TAMANHO_CACHE != (largura_tela, altura_tela):
        _montar_layout(Cena, JOGO)

    tela = tela_destino if tela_destino is not None else JOGO.TELA
    tela.fill((10, 14, 28))

    eventos_ativos = [] if JOGO.GerenciadorSubtelas.ativa else EVENTOS
    mouse_pos = (-99999, -99999) if JOGO.GerenciadorSubtelas.ativa else None

    if _SUBTELA_ATIVA is not None:
        _SUBTELA_ATIVA.render(tela, eventos_ativos, dt)
        return

    _TITULO.draw(tela)

    alterou_fps = _BARRAS["FPS"].render(tela, eventos_ativos, dt)
    alterou_claridade = _BARRAS["Claridade"].render(tela, eventos_ativos, dt)
    alterou_volume = _BARRAS["Volume"].render(tela, eventos_ativos, dt)

    if alterou_fps:
        JOGO.CONFIG["FPS"] = int(round(_BARRAS["FPS"].valor))

    if alterou_claridade:
        JOGO.CONFIG["Claridade"] = int(round(_BARRAS["Claridade"].valor))

    if alterou_volume:
        JOGO.CONFIG["Volume"] = max(0.0, min(1.0, _BARRAS["Volume"].valor / 100.0))
        VerificaSonoridade(JOGO.CONFIG)

    for botao in _BOTOES_TOGGLE.values():
        botao.render(tela, eventos_ativos, dt, JOGO=JOGO, mouse_pos=mouse_pos)

    _BOTAO_CONFIG_AVANCADA.render(tela, eventos_ativos, dt, JOGO=JOGO, mouse_pos=mouse_pos)
    _BOTAO_CONTA.render(tela, eventos_ativos, dt, JOGO=JOGO, mouse_pos=mouse_pos)
    _BOTAO_CANCELAR.render(tela, eventos_ativos, dt, JOGO=JOGO, mouse_pos=mouse_pos)
    _BOTAO_SALVAR.render(tela, eventos_ativos, dt, JOGO=JOGO, mouse_pos=mouse_pos)

import { carregarCsvWiki, limparTexto, numero } from "./WikiCsv.js";
const NOME_CSV = "Pokemon Global Server - Pokemons.csv";
const CAMPOS_NUMERICOS = [
  "Vida",
  "Atk",
  "Def",
  "SpA",
  "SpD",
  "Vel",
  "Mag",
  "Per",
  "Ene",
  "Int",
  "CrD",
  "CrC",
  "Sinergia",
  "Habilidades",
  "Equipaveis",
  "Total",
  "Poder R1",
  "Poder R2",
  "Poder R3",
  "%1",
  "%2",
  "%3",
  "Altura",
  "Peso",
  "Tamanho",
  "Raridade",
  "Code",
  "Linhagem",
];
export const ATRIBUTOS_BASE = [
  { chave: "Vida", rotulo: "Vida" },
  { chave: "Atk", rotulo: "Atk" },
  { chave: "Def", rotulo: "Def" },
  { chave: "SpA", rotulo: "SpA" },
  { chave: "SpD", rotulo: "SpD" },
  { chave: "Vel", rotulo: "Vel" },
  { chave: "Mag", rotulo: "Mag" },
  { chave: "Per", rotulo: "Per" },
  { chave: "Ene", rotulo: "Ene" },
  { chave: "Int", rotulo: "Int" },
  { chave: "CrD", rotulo: "CrD" },
  { chave: "CrC", rotulo: "CrC" },
];
export const ATRIBUTOS_REGULARES = ["Vida", "Atk", "Def", "SpA", "SpD", "Vel", "Mag", "Per", "Ene", "Int"];
const TIPOS_CANONICOS = {
  agua: "Água",
  cosmico: "Cósmico",
  dragao: "Dragão",
  eletrico: "Elétrico",
  fada: "Fada",
  fantasma: "Fantasma",
  fogo: "Fogo",
  gelo: "Gelo",
  grama: "Planta",
  planta: "Planta",
  inseto: "Inseto",
  lutador: "Lutador",
  metal: "Metal",
  normal: "Normal",
  pedra: "Pedra",
  psiquico: "Psíquico",
  sombrio: "Sombrio",
  sombro: "Sombrio",
  sonoro: "Sonoro",
  terrestre: "Terrestre",
  venenoso: "Venenoso",
  voador: "Voador",
};
function calcularFocoAtributo(atributos) {
  return ATRIBUTOS_REGULARES.reduce((melhor, atributo) => {
    const valor = (atributos[atributo] ?? 0) / (atributo === "Vida" ? 2 : 1);
    if (!melhor || valor > melhor.valor) return { atributo, valor };
    return melhor;
  }, null)?.atributo ?? "";
}
export function normalizarChave(valor) {
  return limparTexto(valor)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}
function tipoCanonico(valor) {
  const chave = normalizarChave(valor);
  return TIPOS_CANONICOS[chave] ?? limparTexto(valor).replace(/^./, (letra) => letra.toUpperCase());
}
function nomeBaseRadiante(nome) {
  return String(nome ?? "")
    .replace(/\bradiante\b/gi, "")
    .replace(/\s+/g, " ")
    .trim();
}
export function carregarPokemons() {
  return carregarCsvWiki([NOME_CSV], "Wiki Pokémons").map((linha, indice) => normalizarPokemon(linha, indice));
}
function normalizarPokemon(linha, indice) {
  const normalizado = { ...linha };
  CAMPOS_NUMERICOS.forEach((campo) => {
    normalizado[campo] = numero(linha[campo]);
  });
  const nome = limparTexto(linha.Nome) || `Pokémon ${indice + 1}`;
  const nomeExibicao = nomeBaseRadiante(nome) || nome;
  const code = normalizado.Code ?? indice + 1;
  const tiposUnicos = new Map();
  [
    { nome: limparTexto(linha.Tipo1), chance: normalizado["%1"] },
    { nome: limparTexto(linha.Tipo2), chance: normalizado["%2"] },
    { nome: limparTexto(linha.Tipo3), chance: normalizado["%3"] },
  ].forEach((tipo) => {
    if (!tipo.nome) return;
    const nomeTipo = tipoCanonico(tipo.nome);
    const chave = normalizarChave(nomeTipo);
    if (!tiposUnicos.has(chave)) tiposUnicos.set(chave, { nome: nomeTipo, chance: tipo.chance });
  });
  const tipos = [...tiposUnicos.values()];
  const atributos = Object.fromEntries(ATRIBUTOS_BASE.map((atributo) => [atributo.chave, normalizado[atributo.chave] ?? 0]));
  const focoAtributo = calcularFocoAtributo(atributos);
  return {
    id: String(code ?? indice + 1),
    ordem: indice + 1,
    nome,
    nomeExibicao,
    busca: normalizarChave(`${nome} ${nomeExibicao} ${linha.Grupo ?? ""} ${linha.Tipo1 ?? ""} ${linha.Tipo2 ?? ""} ${linha.Tipo3 ?? ""} ${code ?? ""}`),
    slug: normalizarChave(nome),
    slugBase: normalizarChave(nomeExibicao),
    atributos,
    focoAtributo,
    focoBusca: normalizarChave(focoAtributo),
    vida: atributos.Vida,
    atk: atributos.Atk,
    def: atributos.Def,
    spa: atributos.SpA,
    spd: atributos.SpD,
    vel: atributos.Vel,
    mag: atributos.Mag,
    per: atributos.Per,
    ene: atributos.Ene,
    int: atributos.Int,
    crd: atributos.CrD,
    crc: atributos.CrC,
    sinergia: normalizado.Sinergia,
    habilidades: normalizado.Habilidades,
    equipaveis: normalizado.Equipaveis,
    total: normalizado.Total ?? 0,
    poderR1: normalizado["Poder R1"] ?? 0,
    poderR2: normalizado["Poder R2"] ?? 0,
    poderR3: normalizado["Poder R3"] ?? 0,
    tipos,
    tipoPrincipal: tipos[0]?.nome ?? "sem tipo",
    altura: normalizado.Altura,
    peso: normalizado.Peso,
    tamanho: normalizado.Tamanho,
    grupo: limparTexto(linha.Grupo) || "sem grupo",
    raridade: normalizado.Raridade,
    raridadeTexto: limparTexto(linha.Raridade) || "-",
    estagio: limparTexto(linha.Estagio) || "-",
    formaFinal: limparTexto(linha.FF),
    code,
    linhagem: normalizado.Linhagem ?? code ?? indice + 1,
  };
}
function arquivoSemExtensao(caminho) {
  const arquivo = caminho.split(/[\\/]/).pop() ?? caminho;
  return arquivo.replace(/\.[^.]+$/, "");
}
export function indexarArquivosPorNome(glob) {
  const indice = {};
  Object.entries(glob).forEach(([caminho, url]) => {
    const chave = normalizarChave(arquivoSemExtensao(caminho));
    if (chave && !indice[chave]) indice[chave] = url;
  });
  return indice;
}
export function indexarFramesPorPasta(glob) {
  const grupos = {};
  Object.entries(glob).forEach(([caminho, url]) => {
    const partes = caminho.split(/[\\/]/).filter(Boolean);
    const pasta = partes.at(-2) ?? "";
    const chave = normalizarChave(pasta);
    if (!chave) return;
    if (!grupos[chave]) grupos[chave] = [];
    grupos[chave].push({ caminho, url });
  });
  Object.values(grupos).forEach((frames) => {
    frames.sort((a, b) => a.caminho.localeCompare(b.caminho, "pt-BR", { numeric: true, sensitivity: "base" }));
  });
  return Object.fromEntries(Object.entries(grupos).map(([chave, frames]) => [chave, frames.map((frame) => frame.url)]));
}
function candidatosPokemon(pokemon) {
  const codigo = String(pokemon.code ?? pokemon.id ?? "");
  const nome = pokemon.nome ?? "";
  const baseRadiante = nomeBaseRadiante(nome);
  return [
    codigo,
    codigo.padStart(3, "0"),
    `pokemon${codigo}`,
    `poke${codigo}`,
    nome,
    pokemon.slug,
    pokemon.slugBase,
    nome?.replace(/\s+/g, "_"),
    nome?.replace(/\s+/g, "-"),
    baseRadiante,
    baseRadiante?.replace(/\s+/g, "_"),
    baseRadiante?.replace(/\s+/g, "-"),
  ]
    .filter(Boolean)
    .map(normalizarChave);
}
export function resolverImagemPokemon(pokemon, imagensPorNome) {
  for (const candidato of candidatosPokemon(pokemon)) {
    if (imagensPorNome[candidato]) return imagensPorNome[candidato];
  }
  return null;
}
export function resolverFramesPokemon(pokemon, framesPorPasta) {
  for (const candidato of candidatosPokemon(pokemon)) {
    if (framesPorPasta[candidato]?.length) return framesPorPasta[candidato];
  }
  return [];
}
export function criarAssetsPokemons(pokemons, imagensPorNome, framesPorPasta = null) {
  return Object.fromEntries(
    pokemons.map((pokemon) => {
      const frames = framesPorPasta ? resolverFramesPokemon(pokemon, framesPorPasta) : [];
      return [
        pokemon.id,
        frames.length
          ? { imagem: resolverImagemPokemon(pokemon, imagensPorNome), frames }
          : { imagem: resolverImagemPokemon(pokemon, imagensPorNome) },
      ];
    }),
  );
}
export function resumoPokemons(pokemons) {
  const tiposPorChave = new Map();
  pokemons.flatMap((pokemon) => pokemon.tipos.map((tipo) => tipo.nome)).forEach((tipo) => {
    const chave = normalizarChave(tipo);
    if (chave && !tiposPorChave.has(chave)) tiposPorChave.set(chave, tipoCanonico(tipo));
  });
  const tipos = [...tiposPorChave.values()].sort((a, b) => a.localeCompare(b, "pt-BR"));
  const grupos = [...new Set(pokemons.map((pokemon) => pokemon.grupo).filter(Boolean))].sort((a, b) =>
    a.localeCompare(b, "pt-BR"),
  );
  const focos = [...new Set(pokemons.map((pokemon) => pokemon.focoAtributo).filter(Boolean))];
  const linhagens = new Set(pokemons.map((pokemon) => String(pokemon.linhagem)).filter(Boolean));
  const raridades = [...new Set(pokemons.map((pokemon) => pokemon.raridadeTexto).filter(Boolean))].sort((a, b) => {
    const na = Number(a);
    const nb = Number(b);
    if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
    return a.localeCompare(b, "pt-BR", { numeric: true });
  });
  const maximos = Object.fromEntries(
    ATRIBUTOS_BASE.map((atributo) => [atributo.chave, Math.max(1, ...pokemons.map((pokemon) => pokemon.atributos[atributo.chave] ?? 0))]),
  );
  return {
    quantidade: pokemons.length,
    tipos,
    grupos,
    focos,
    linhagens: linhagens.size,
    raridades,
    maximos,
    maiorTotal: Math.max(1, ...pokemons.map((pokemon) => pokemon.total ?? 0)),
    maiorPoderR3: Math.max(1, ...pokemons.map((pokemon) => pokemon.poderR3 ?? 0)),
  };
}
export function selecionarDestaquesHome(pokemons, limite = 36, imagensPorNome = null) {
  const validos = [...pokemons].filter((pokemon) => pokemon?.id && pokemon?.nome && (!imagensPorNome || resolverImagemPokemon(pokemon, imagensPorNome)));
  for (let i = validos.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [validos[i], validos[j]] = [validos[j], validos[i]];
  }
  return validos.slice(0, Math.min(limite, validos.length));
}
